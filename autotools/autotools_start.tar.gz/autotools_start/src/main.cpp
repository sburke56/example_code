#include <cstdio> 

int main( int argc, char* argv[] )
{
    printf("hello world\n"); 
    return 0; 
}

