#include <cppunit/config/SourcePrefix.h>
#include "ExampleTestCase.h"

CPPUNIT_TEST_SUITE_REGISTRATION( ExampleTestCase );

void ExampleTestCase::setUp()
{
}

void ExampleTestCase::tearDown()
{
}

void ExampleTestCase::test_UnitTestName()
{
    CPPUNIT_ASSERT( 42 == 42 );
}
