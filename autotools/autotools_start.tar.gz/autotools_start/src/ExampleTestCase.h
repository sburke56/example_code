#ifndef EXAMPLE_TEST_CASE_H
#define EXAMPLE_TEST_CASE_H

#include <cppunit/extensions/HelperMacros.h>

class ExampleTestCase : public CPPUNIT_NS::TestFixture
{
    CPPUNIT_TEST_SUITE( ExampleTestCase );
    CPPUNIT_TEST( test_UnitTestName );
    CPPUNIT_TEST_SUITE_END();

  public:
    void setUp();
    void tearDown(); 
   
  private: 
    void test_UnitTestName();
};

#endif
