#! /usr/bin/python 

import subprocess
from subprocess import Popen, PIPE, STDOUT

def get_kernel_release(): 
    p = subprocess.Popen(['uname', '-r'], stdout=PIPE)
    kernel_release = p.communicate()[0]
    return kernel_release

def get_installed_kernel_headers(): 
    p1 = subprocess.Popen(['aptitude', 'search', 'linux-headers-2.6.*', '-F', '%c %p', '--disable-columns'], stdout=PIPE)
    p2 = Popen(["grep", "^i"], stdin=p1.stdout, stdout=PIPE)
    
    headers_installed = []
    for ln in p2.stdout:
        headers_installed.append(ln.rstrip()[2:])
    return headers_installed

def get_installed_kernel_images(): 
    p1 = subprocess.Popen(['aptitude', 'search', 'linux-image-2.6.*', '-F', '%c %p', '--disable-columns'], stdout=PIPE)
    p2 = Popen(["grep", "^i"], stdin=p1.stdout, stdout=PIPE)
    
    images_installed = []
    for ln in p2.stdout:
        images_installed.append(ln.rstrip()[2:])
    return images_installed

def remove_packages(packages, dry_run): 
    remove_args = ['aptitude', 'remove', '-P']
    remove_args.extend(packages)

    if dry_run: 
        print 'Dry Run: %s' % ' '.join(remove_args)
    else: 
        subprocess.call(remove_args)

def update_grub(): 
    subprocess.call(['update-grub'])
