#! /usr/bin/python 

import wx
import wx.lib.mixins.listctrl  as  listmix
import sys
from apthelpers import * 

class TGListCtrl(wx.ListCtrl, listmix.ListCtrlAutoWidthMixin):
    def __init__(self, parent, ID, pos=wx.DefaultPosition,
                 size=wx.DefaultSize, style=0):
        wx.ListCtrl.__init__(self, parent, ID, pos, size, style)
        listmix.ListCtrlAutoWidthMixin.__init__(self)


class TGFrame(wx.Frame):
    def __init__(self, parent, id, title):
        wx.Frame.__init__(self, parent, id, title, (-1, -1), wx.Size(450, 300))

        self.panel = wx.Panel(self, -1)
        self.box = wx.BoxSizer(wx.VERTICAL)

        lID = wx.NewId()
        self.grubmenuentries = TGListCtrl(self.panel, lID,
                                          style=wx.LC_REPORT | wx.LC_SORT_DESCENDING)
        self.trimbutton = wx.Button(self.panel, -1, 'Trim Menu')

        self.box.Add(self.grubmenuentries, 1, wx.EXPAND, border=5)
        self.box.Add(self.trimbutton, 0, wx.ALIGN_CENTER, border=5)
        self.panel.SetSizer(self.box)
        self.Centre()

        self.Bind(wx.EVT_BUTTON, self.trimbutton_OnClick, self.trimbutton)
        
    def PopulateList(self, menu_entries): 
        self.grubmenuentries.InsertColumn(0, "Grub Menu Entry", width=-1, format=wx.LIST_FORMAT_LEFT)
        for entry in menu_entries:   
            self.grubmenuentries.InsertStringItem(sys.maxint, entry)

    def SelectEntriesToTrim(self): 
        num_entries_to_keep = 2
        count = self.grubmenuentries.GetItemCount()
        for x in range(num_entries_to_keep): 
            self.grubmenuentries.SetItemState(count-1-x, wx.LIST_STATE_SELECTED, wx.LIST_STATE_SELECTED)

    def trimbutton_OnClick(self, event):
        selected_ids = self.get_selected_items(self.grubmenuentries)
        packages = []
        for x in selected_ids:
            packages.append(self.grubmenuentries.GetItem(x,0).GetText())

        remove_packages(packages, False)

    def get_selected_items(self, list_control):
        """
        Gets the selected items for the list control.
        Selection is returned as a list of selected indices,
        low to high.
        """
        selection = []
    
        # start at -1 to get the first selected item
        index = list_control.GetFirstSelected()
        if index == -1: 
            return

        while index != -1:
            selection.append(index)
            index = list_control.GetNextSelected(index)

        return selection
