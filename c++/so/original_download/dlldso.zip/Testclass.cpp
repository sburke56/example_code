//
// simple class for use in developing a common scheme for building DLL and DSO
// versions of shared libraries while exporting only some of the symbols.
//

#include "Testclass.hpp"
#include "Hiddenclass.hpp"


//using namespace std;


Testclass::Testclass(int a, int b)
{
  phc = new Hiddenclass(a,b);
}

Testclass::~Testclass() {;}
int Testclass::multiply() const { return phc->multiply(); }
int Testclass::divide() const { return phc->divide(); }
int Testclass::add() const { return phc->add(); }
int Testclass::subtract() const { return phc->subtract(); }

